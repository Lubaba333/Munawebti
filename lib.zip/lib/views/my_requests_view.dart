import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:studants/controllers/request_controller.dart';
import 'package:studants/utlis/app_colors.dart';
import 'package:studants/views/exit_permission_view.dart';
import 'package:studants/views/room_exchange_view.dart';
import 'package:studants/views/room_transfer_view.dart';
import 'package:studants/views/specific_room_change_view.dart';
import 'package:studants/views/sent_requests_tab.dart';
import 'package:studants/views/incoming_requests_tab.dart';

class MyRequestsView extends StatefulWidget {
  const MyRequestsView({super.key});

  @override
  State<MyRequestsView> createState() => _MyRequestsViewState();
}

class _MyRequestsViewState extends State<MyRequestsView>
    with SingleTickerProviderStateMixin {
  final RequestController controller = Get.isRegistered<RequestController>()
      ? Get.find<RequestController>()
      : Get.put(RequestController());

  late TabController tabController;

  @override
  void initState() {
    super.initState();

    tabController = TabController(length: 2, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await controller.getCurrentStudentRoom();
      await controller.getMyRequests();
    });
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _newRequestButton(),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.mainGradient),
        child: SafeArea(
          child: Column(
            children: [
              _header(),
              _tabs(),
              Expanded(child: _body()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Get.back(),
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              "طلباتي",
              style: TextStyle(
                color: Colors.white,
                fontSize: 27,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabs() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 4, 20, 12),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.18),
        borderRadius: BorderRadius.circular(18),
      ),
      child: TabBar(
        controller: tabController,
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        labelColor: AppColors.darkPurple,
        unselectedLabelColor: Colors.white,
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: "طلباتي"),
          Tab(text: "الواردة"),
        ],
      ),
    );
  }

  Widget _body() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
      ),
      child: TabBarView(
        controller: tabController,
        children: [
          SentRequestsTab(controller: controller),
          IncomingRequestsTab(controller: controller),
        ],
      ),
    );
  }

  Widget _newRequestButton() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
        color: Colors.white,
        child: GestureDetector(
          onTap: _showNewRequestSheet,
          child: Container(
            height: 56,
            decoration: BoxDecoration(
              gradient: AppColors.mainGradient,
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.add_circle_outline, color: Colors.white),
                SizedBox(width: 10),
                Text(
                  "طلب جديد",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showNewRequestSheet() {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "إنشاء طلب جديد",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: AppColors.darkPurple,
              ),
            ),
            const SizedBox(height: 20),
            _sheetItem(Icons.exit_to_app, "سماح خروج من السكن", () {
              Get.back();
              Get.to(() => ExitPermissionView());
            }),
            _sheetItem(Icons.meeting_room, "تبديل غرفة بدون بديلة", () {
              Get.back();
              Get.to(() => const SpecificRoomChangeView());
            }),
            _sheetItem(Icons.swap_horiz, "تبديل غرفة مع طالبة", () {
              Get.back();
              Get.to(() => const RoomExchangeView());
            }),
            _sheetItem(Icons.move_up, "نقل لأي غرفة متاحة", () {
              Get.back();
              Get.to(() => const RoomTransferView());
            }),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }

  Widget _sheetItem(IconData icon, String title, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.softLavender.withOpacity(.6),
        borderRadius: BorderRadius.circular(18),
      ),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: Colors.white,
          child: Icon(icon, color: AppColors.darkPurple),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      ),
    );
  }
}